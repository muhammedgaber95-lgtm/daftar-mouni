package com.mouni.daftar

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "مهمة من دفتر موني"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel("mouni_tasks", "تذكيرات المهام", NotificationManager.IMPORTANCE_HIGH)
        )
        val notification = NotificationCompat.Builder(context, "mouni_tasks")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("حان وقت مهمتك يا موني")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("daftar_mouni", Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString("tasks", "[]"))
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optBoolean("done")) continue
            val due = o.optLong("dueAt") - o.optInt("reminderMinutes", 15) * 60_000L
            if (due <= System.currentTimeMillis()) continue
            val pi = PendingIntent.getBroadcast(context, o.optLong("id").toInt(),
                Intent(context, ReminderReceiver::class.java).putExtra("title", o.optString("title")),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi) }
            catch (_: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi) }
        }
    }
}
