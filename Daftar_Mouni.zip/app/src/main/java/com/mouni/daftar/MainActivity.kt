package com.mouni.daftar

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val navy = Color.rgb(11, 23, 40)
    private val card = Color.rgb(23, 41, 65)
    private val coral = Color.rgb(255, 157, 137)
    private val pale = Color.rgb(238, 244, 251)
    private val muted = Color.rgb(174, 194, 216)
    private val prefs by lazy { getSharedPreferences("daftar_mouni", MODE_PRIVATE) }
    private val tasks = mutableListOf<Task>()
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private var selectedDay: Long = dayStart(System.currentTimeMillis())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy; window.navigationBarColor = navy
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 71)
        load()
        render()
    }

    private fun dayStart(t: Long): Long {
        val c = Calendar.getInstance().apply { timeInMillis = t; set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
        return c.timeInMillis
    }

    private fun load() {
        tasks.clear()
        val a = JSONArray(prefs.getString("tasks", "[]"))
        for (i in 0 until a.length()) try { tasks.add(Task.from(a.getJSONObject(i))) } catch (_: Exception) {}
    }
    private fun save() {
        val a = JSONArray(); tasks.forEach { a.put(it.json()) }
        prefs.edit().putString("tasks", a.toString()).apply()
    }

    private fun txt(s: String, size: Float, color: Int = pale, bold: Boolean = false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); gravity=Gravity.RIGHT; textDirection=View.TEXT_DIRECTION_RTL }

    private fun button(s: String, primary: Boolean = false, action: () -> Unit): TextView =
        txt(s, 15f, if (primary) navy else pale, true).apply {
            gravity=Gravity.CENTER; setPadding(20, 18, 20, 18); setBackgroundColor(if (primary) coral else card)
            setOnClickListener { action() }
        }

    private fun render() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(navy); layoutDirection=View.LAYOUT_DIRECTION_RTL; setPadding(18,16,18,10) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        content.addView(txt("دفتر موني  ♡", 27f, coral, true).apply { setPadding(0,8,0,4) })
        content.addView(txt("خطّط يومك .. وحقق أحلامك", 14f, muted).apply { setPadding(0,0,0,18) })
        val dateFormat = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar"))
        content.addView(button("📅  ${dateFormat.format(Date(selectedDay))}  — تغيير التاريخ") { chooseDay() }.apply { setPadding(12,16,12,16) })
        val todayTasks = tasks.filter { dayStart(it.dueAt) == selectedDay }
        val done = todayTasks.count { it.done }
        summary = txt("إنجاز اليوم   $done / ${todayTasks.size}   •   ${if (todayTasks.isEmpty()) 0 else done*100/todayTasks.size}%", 17f, pale, true)
        summary.setPadding(0,18,0,12); content.addView(summary)
        content.addView(button("＋  إضافة مهمة جديدة", true) { addTask() }.apply { setPadding(12,17,12,17) })
        content.addView(txt("مهام اليوم", 20f, pale, true).apply { setPadding(0,20,0,10) })
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val sorted = todayTasks.sortedWith(compareBy<Task> { it.done }.thenBy { it.dueAt })
        if (sorted.isEmpty()) list.addView(txt("مفيش مهام في اليوم ده.\nاضغط «إضافة مهمة جديدة» وابدأ خطتك ✨", 16f, muted).apply { setPadding(8,28,8,28) })
        sorted.forEach { t -> list.addView(taskCard(t)) }
        content.addView(list)
        content.addView(txt("تلميحة موني", 18f, coral, true).apply { setPadding(0,24,0,6) })
        content.addView(txt("ابدأ بالأهم، وسيأتي الباقي خطوة بخطوة.", 14f, muted).apply { setPadding(0,0,0,20) })
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,10,0,0) }
        nav.addView(button("اليوم", false) { selectedDay=dayStart(System.currentTimeMillis()); render() }, LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(button("كل المهام", false) { showAll() }, LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(button("التقويم", false) { chooseDay() }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(nav)
        setContentView(root)
    }

    private fun taskCard(t: Task): View {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,12,14,12); setBackgroundColor(card) }
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val check = CheckBox(this).apply { isChecked=t.done; buttonTintList=android.content.res.ColorStateList.valueOf(if(t.done) Color.rgb(85,214,176) else coral); setOnCheckedChangeListener { _, v -> update(t.copy(done=v)) } }
        row.addView(check)
        val title = txt(t.title, 16f, if(t.done) muted else pale, true).apply { gravity=Gravity.RIGHT; setPadding(8,0,8,0) }
        row.addView(title, LinearLayout.LayoutParams(0,-2,1f))
        val time = SimpleDateFormat("h:mm a", Locale("en")).format(Date(t.dueAt))
        row.addView(txt(time, 13f, coral, true))
        box.addView(row)
        val priColor = when(t.priority) { "عالية" -> Color.rgb(255,111,119); "منخفضة" -> Color.rgb(93,164,255); else -> Color.rgb(255,176,78) }
        box.addView(txt("● ${t.priority}   •   ${if(t.reminderMinutes<0) "بدون تذكير" else "تذكير قبل ${t.reminderMinutes} دقيقة"}", 12f, priColor).apply { setPadding(8,4,8,0) })
        box.setOnLongClickListener { AlertDialog.Builder(this).setTitle("إدارة المهمة").setItems(arrayOf("تعديل المهمة", "حذف المهمة")) { _, which ->
            if(which==0) editTask(t) else { cancelReminder(t.id); tasks.removeAll { it.id==t.id }; save(); render() }
        }.show(); true }
        val lp = LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,10); box.layoutParams=lp
        return box
    }

    private fun update(t: Task) {
        val i=tasks.indexOfFirst { it.id==t.id }; if(i>=0) tasks[i]=t
        if(t.done) cancelReminder(t.id) else scheduleReminder(t)
        save(); render()
    }

    private fun chooseDay() {
        val c=Calendar.getInstance().apply { timeInMillis=selectedDay }
        DatePickerDialog(this,{ _, y,m,d ->
            val x=Calendar.getInstance().apply { set(y,m,d,0,0,0); set(Calendar.MILLISECOND,0) }
            selectedDay=x.timeInMillis; render()
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun addTask() { taskDialog(null) }
    private fun editTask(t: Task) { taskDialog(t) }

    private fun taskDialog(old: Task?) {
        val wrap=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,8,24,8) }
        val name=EditText(this).apply { hint="اسم المهمة"; setText(old?.title ?: ""); textDirection=View.TEXT_DIRECTION_RTL }
        wrap.addView(name)
        val date=button("📅  ${SimpleDateFormat("dd/MM/yyyy",Locale("en")).format(Date(old?.dueAt ?: selectedDay))}") {} 
        wrap.addView(date)
        var due=Calendar.getInstance().apply { timeInMillis=old?.dueAt ?: (selectedDay+9*60*60*1000L) }
        date.setOnClickListener {
            DatePickerDialog(this,{ _,y,m,d ->
                due.set(y,m,d)
                date.text="📅  ${SimpleDateFormat("dd/MM/yyyy",Locale("en")).format(due.time)}"
            },due.get(Calendar.YEAR),due.get(Calendar.MONTH),due.get(Calendar.DAY_OF_MONTH)).show()
        }
        val time=button("🕒  ${SimpleDateFormat("HH:mm",Locale("en")).format(due.time)}") {}
        wrap.addView(time)
        time.setOnClickListener { TimePickerDialog(this,{ _,h,m -> due.set(Calendar.HOUR_OF_DAY,h); due.set(Calendar.MINUTE,m); due.set(Calendar.SECOND,0); time.text="🕒  ${String.format("%02d:%02d",h,m)}" },due.get(Calendar.HOUR_OF_DAY),due.get(Calendar.MINUTE),true).show() }
        val pri=Spinner(this)
        pri.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("عالية","متوسطة","منخفضة"))
        pri.setSelection(listOf("عالية","متوسطة","منخفضة").indexOf(old?.priority ?: "متوسطة").coerceAtLeast(0))
        wrap.addView(txt("الأولوية",14f,muted).apply { setPadding(0,12,0,2) }); wrap.addView(pri)
        val rem=Spinner(this)
        val remLabels=listOf("قبلها بـ 15 دقيقة","قبلها بـ 30 دقيقة","في موعد المهمة","بدون تذكير")
        rem.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,remLabels)
        val remValues=listOf(15,30,0,-1)
        rem.setSelection(remValues.indexOf(old?.reminderMinutes ?: 15).coerceAtLeast(0))
        wrap.addView(txt("التنبيه",14f,muted).apply { setPadding(0,12,0,2) }); wrap.addView(rem)
        AlertDialog.Builder(this).setTitle(if(old==null) "مهمة جديدة" else "تعديل المهمة").setView(wrap)
            .setNegativeButton("إلغاء",null).setPositiveButton("حفظ") { _,_ ->
                val title=name.text.toString().trim()
                if(title.isNotEmpty()) {
                    val task=Task(old?.id ?: System.currentTimeMillis(),title,due.timeInMillis,pri.selectedItem.toString(),remValues[rem.selectedItemPosition],old?.done ?: false)
                    if(old!=null) cancelReminder(old.id)
                    tasks.removeAll { it.id==task.id }; tasks.add(task); selectedDay=dayStart(task.dueAt); save()
                    if(!task.done) scheduleReminder(task)
                    render()
                } else Toast.makeText(this,"اكتب اسم المهمة أولاً",Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun scheduleReminder(t: Task) {
        if(t.reminderMinutes<0 || t.done) return
        val at=t.dueAt-t.reminderMinutes*60_000L
        if(at<System.currentTimeMillis()) return
        val am=getSystemService(ALARM_SERVICE) as AlarmManager
        val pi=PendingIntent.getBroadcast(this,t.id.toInt(),Intent(this,ReminderReceiver::class.java).putExtra("title",t.title),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi) }
        catch (_: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi) }
    }
    private fun cancelReminder(id: Long) {
        val pi=PendingIntent.getBroadcast(this,id.toInt(),Intent(this,ReminderReceiver::class.java),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if(pi!=null) (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi)
    }

    private fun showAll() {
        val lines=tasks.sortedBy { it.dueAt }.joinToString("\n\n") { t ->
            "${if(t.done) "✓" else "○"} ${t.title}\n${SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("en")).format(Date(t.dueAt))} • ${t.priority}"
        }.ifBlank { "لسه مفيش مهام محفوظة." }
        AlertDialog.Builder(this).setTitle("كل المهام").setMessage(lines).setPositiveButton("تمام",null).show()
    }
}
