package com.mouni.daftar

import org.json.JSONObject

data class Task(
    val id: Long,
    val title: String,
    val dueAt: Long,
    val priority: String,
    val reminderMinutes: Int,
    val done: Boolean = false
) {
    fun json() = JSONObject().apply {
        put("id", id); put("title", title); put("dueAt", dueAt)
        put("priority", priority); put("reminderMinutes", reminderMinutes); put("done", done)
    }
    companion object {
        fun from(o: JSONObject) = Task(
            o.optLong("id"), o.optString("title"), o.optLong("dueAt"),
            o.optString("priority", "متوسطة"), o.optInt("reminderMinutes", 15), o.optBoolean("done")
        )
    }
}
